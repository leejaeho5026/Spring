SELECT * FROM user_table
 WHERE user_id = 'JAVA';
 
SELECT * FROM user_table
 WHERE user_id = 'JAVA' and user_pw=159623; 
 
SELECT user_idx, user_name FROM user_table
 WHERE user_id = 'JAVA' and user_pw='159623';
 
DESC user_table; 

SELECT * FROM user_table;

SELECT user_id, user_name
  FROM user_table
 WHERE user_idx = 6; 

