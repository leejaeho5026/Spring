SELECT * FROM USER_TABLE;

desc USER_TABLE;

SELECT user_name 
  FROM user_table
 WHERE user_id = 'springMVC';
 
SELECT *
  FROM user_table;