package kr.co.tjoeun.dao;

import org.springframework.stereotype.Repository;

@Repository
public class TestDAO {  
  public String testDaoMethod() {
	return "더조은학원";
  }

}
