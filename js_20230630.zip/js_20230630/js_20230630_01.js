console.log(true);
console.log({name:'더조은', age:23, married:false});
console.log('Hello', 111, false, [11, 22, 33]);

// 한 줄 주석
/*
 여러 줄
 주석
*/
console.log('Hello Web'); console.log('Hello Web')

